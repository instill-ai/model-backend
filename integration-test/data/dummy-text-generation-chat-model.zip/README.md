---
Task: TextGenerationChat
Tags:
  - TextGenerationChat
  - GPT-2
  - Test
---

# Test repo

This is dummy Text Generation Chat model used for testing purpose
