---
Task: TextGenerationChat
Tags:
  - TextGenerationChat
  - Test
---

# Test repo
This is a dummy text generation chat model for testing purpose
