# -*- coding: utf-8 -*-
import csv
import json
import numpy as np
import torch
import triton_python_backend_utils as pb_utils
import logging
logger = logging.getLogger()
from pathlib import Path
from torch.nn.utils.rnn import pad_sequence

class TritonPythonModel:

    def initialize(self, args):

        # Parse model configs
        self.model_config = model_config = json.loads(args['model_config'])

        # Parse model output configs and convert Triton types to numpy types
        input_names = ["prompt"]
        for input_name in input_names:
          setattr(self,
              input_name.lower() + "_dtype",
              pb_utils.triton_string_to_numpy(pb_utils.get_output_config_by_name(
                model_config, input_name)['data_type'])
          )

    def execute(self, requests):

        responses = []

        # Every Python backend must iterate over everyone of the requests
        # and create a pb_utils.InferenceResponse for each of them.
        for idx, request in enumerate(requests):
            # Get input tensors
            logger.info(request)
            prompt = pb_utils.get_input_tensor_by_name(request, 'prompt').as_numpy()
            
            prompt_tensor = pb_utils.Tensor(
                'prompt',
                prompt
            )

            inference_response = pb_utils.InferenceResponse(output_tensors=[
                prompt_tensor
            ])
            responses.append(inference_response)

        # You should return a list of pb_utils.InferenceResponse. Length
        # of this list must match the length of `requests` list.
        return responses


    def finalize(self):
        print('Cleaning up...')
