---
Task: InstanceSegmentation
Tags:
  - InstanceSegmentation
  - Test
---

# Test repo
This is a dummy instance segmentation model for testing purpose
