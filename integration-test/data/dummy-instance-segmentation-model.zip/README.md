---
Task: InstanceSegmentation
Tags:
  - InstanceSegmentation
  - Test
---

# Test repo
This is dummy instance segmentation model used for testing purpose