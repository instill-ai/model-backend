import numpy as np
import json
import sys
import os

from pathlib import Path
from typing import List
from PIL import Image

from triton_python_backend_utils import get_output_config_by_name, triton_string_to_numpy
from c_python_backend_utils import Tensor, InferenceResponse, InferenceRequest

class TritonPythonModel(object):
    def __init__(self):
        self.input_names = {
            'orig_img_hw': 'orig_img_hw'
        }
        self.output_names = {
            'rles': 'rles',
            'bounding_boxes': 'bounding_boxes',
            'categories': 'categories',
            'scores': 'scores',
        }

    def initialize(self, args):
        model_config = json.loads(args['model_config'])

        output_configs = {k: get_output_config_by_name(
            model_config, name) for k, name in self.output_names.items()}

        self.output_dtypes = {k: triton_string_to_numpy(
            cfg['data_type']) for k, cfg in output_configs.items()}

    def execute(self, inference_requests: List[InferenceRequest]) -> List[InferenceResponse]:
        responses = []

        for request in inference_requests:
            batch_out = {k: [] for k, name in self.output_names.items(
            ) if name in request.requested_output_names()}
            for i in range(request.inputs()[0].as_numpy().shape[0]):
                batch_out['rles'].append(["2918,12,382,33,96,25,248,39,88,41,236,43,82,49,230,47,77,55,225,50,74,61,218,55,69,67,211,62,62,76,202,69,53,87,192,77,45,96,185,82,39,103,180,85,34,109,177,88,29,114,174,90,25,119,170,98,14,127,166,243,162,247,158,251,153,255,149,259,146,262,142,266,139,270,135,273,132,276,130,279,126,282,123,285,121,288,118,290,115,295,111,300,106,311,94,323,83,332,74,339,66,346,59,350,56,354,51,360,45,365,33,375,31,377,29,379,27,380,26,382,24,383,23,385,21,387,19,388,18,389,17,389,17,389,17,389,17,389,17,389,17,389,17,388,18,388,18,388,18,387,19,387,19,386,20,386,20,385,21,384,22,383,23,382,24,380,26,378,35,369,38,366,41,363,44,359,47,358,49,356,50,355,52,353,53,352,54,351,56,349,57,349,57,349,57,349,58,348,58,348,58,348,58,348,58,348,58,348,59,347,59,347,59,347,59,347,59,347,60,346,60,346,60,345,62,344,63,343,64,342,64,342,66,340,67,339,68,338,69,336,71,335,72,333,74,332,75,330,76,330,77,328,78,328,79,327,80,326,81,326,81,325,83,323,84,323,85,321,86,324,83,328,78,342,65,349,58,354,52,364,43,363,43,363,44,362,44,362,44,362,45,361,45,361,46,360,47,359,47,60,6,293,49,55,18,284,51,49,25,281,54,41,31,280,57,31,40,278,59,23,47,277,62,12,56,276,64,3,64,275,131,275,133,273,134,272,136,270,139,267,141,265,142,264,144,262,145,261,147,259,150,256,153,253,158,248,161,245,164,242,166,240,169,237,174,232,179,227,185,221,190,208,202,202,207,198,211,194,214,190,220,184,227,177,233,170,240,163,246,157,251,153,255,149,260,143,266,137,273,130,280,124,285,119,289,116,292,112,296,108,300,104,306,98,312,92,317,87,321,84,325,80,328,77,331,73,336,69,339,65,344,59,350,54,355,50,358,47,360,44,364,41,368,35,374,28,386,13,2525"])
                batch_out['bounding_boxes'].append([[1, 1, 100, 100]])
                batch_out['categories'].append(["dog"])
                batch_out['scores'].append([1.0])

            # Format outputs to build an InferenceResponse
            output_tensors = [Tensor(self.output_names[k], np.asarray(
                out, dtype=self.output_dtypes[k])) for k, out in batch_out.items()]

            # TODO: should set error field from InferenceResponse constructor to handle errors
            # https://github.com/triton-inference-server/python_backend#execute
            # https://github.com/triton-inference-server/python_backend#error-handling
            response = InferenceResponse(output_tensors)
            responses.append(response)

        return responses        