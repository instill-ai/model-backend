---
Tags:
  - Classification
  - Test
---

# Test repo
This is dummy undefined model used for testing purpose