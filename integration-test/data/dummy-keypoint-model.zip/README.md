---
Task: Keypoint
Tags:
  - Keypoint
  - Test
---

# Test repo
This is dummy keypoint model used for testing purpose