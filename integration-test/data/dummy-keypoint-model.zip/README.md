---
Task: Keypoint
Tags:
  - Keypoint
  - Test
---

# Test repo
This is a dummy keypoint model for testing purpose
