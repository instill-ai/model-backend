---
Task: TextGenerationChat
Tags:
  - TextGenerationChat
  - Llama_7b
  - Test
---

# Test repo

This is dummy Text Generation model used for testing purpose
