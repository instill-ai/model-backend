# -*- coding: utf-8 -*-
import json
from pathlib import Path
import numpy as np
import torch
from torch.nn.utils.rnn import pad_sequence
import triton_python_backend_utils as pb_utils


class TritonPythonModel:

    def initialize(self, args):

        # Parse model configs
        self.model_config = model_config = json.loads(args['model_config'])

        # Parse model output configs
        output_config = pb_utils.get_output_config_by_name(
            model_config, "output")

        # Convert Triton types to numpy types
        self.output_dtype= pb_utils.triton_string_to_numpy(
            output_config['data_type'])

    def execute(self, requests):
        responses = []

        # Every Python backend must iterate over everyone of the requests
        # and create a pb_utils.InferenceResponse for each of them.
        for idx, request in enumerate(requests):
            prompt = pb_utils.get_input_tensor_by_name(request, 'conversation').as_numpy()
            # prompt = str(pb_utils.get_input_tensor_by_name(request, "prompt").as_numpy()[0].decode("utf-8"))
            print(f'[DEBUG] input `prompt` type({type(prompt)}): {prompt}')
            parsed_conversation = json.loads(prompt)
            print(f'[DEBUG] input `parsed_conversation` type({type(parsed_conversation)}): {parsed_conversation}')
            # Create output tensors. You need pb_utils.Tensor
            # objects to create pb_utils.InferenceResponse.
            output_tensor = pb_utils.Tensor(
                'output',
                np.array([prompt]).astype(self.output_dtype))

            # Create InferenceResponse. You can set an error here in case
            # there was a problem with handling this inference request.
            # Below is an example of how you can set errors in inference
            # response:
            #
            # pb_utils.InferenceResponse(
            #    output_tensors=..., TritonError("An error occurred"))
            inference_response = pb_utils.InferenceResponse(output_tensors=[
                output_tensor])
            responses.append(inference_response)

        # You should return a list of pb_utils.InferenceResponse. Length
        # of this list must match the length of `requests` list.
        return responses


    def finalize(self):
        print('Cleaning up...')
