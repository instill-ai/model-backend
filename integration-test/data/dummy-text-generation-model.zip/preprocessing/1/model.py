# -*- coding: utf-8 -*-
import csv
import json
import numpy as np
import torch
import triton_python_backend_utils as pb_utils
import logging
logger = logging.getLogger()
from pathlib import Path
from torch.nn.utils.rnn import pad_sequence

class TritonPythonModel:

    def initialize(self, args):

        # Parse model configs
        self.model_config = model_config = json.loads(args['model_config'])

        # Parse model output configs and convert Triton types to numpy types
        input_names = ["QUERY"]
        for input_name in input_names:
          setattr(self,
              input_name.lower() + "_dtype",
              pb_utils.triton_string_to_numpy(pb_utils.get_output_config_by_name(
                model_config, input_name)['data_type'])
          )

    def execute(self, requests):

        responses = []

        # Every Python backend must iterate over everyone of the requests
        # and create a pb_utils.InferenceResponse for each of them.
        for idx, request in enumerate(requests):
            # Get input tensors
            logger.info(request)
            query = pb_utils.get_input_tensor_by_name(request, 'QUERY').as_numpy()
            request_output_len = pb_utils.get_input_tensor_by_name(request, 'REQUEST_OUTPUT_LEN').as_numpy()

            bad_words_dict = pb_utils.get_input_tensor_by_name(request, 'BAD_WORDS_DICT').as_numpy()
            stop_words_dict = pb_utils.get_input_tensor_by_name(request, 'STOP_WORDS_DICT').as_numpy()

            runtime_top_k = pb_utils.get_input_tensor_by_name(request, 'runtime_top_k').as_numpy()
            random_seed = pb_utils.get_input_tensor_by_name(request, 'random_seed').as_numpy()


            query_tensor = pb_utils.Tensor(
                'QUERY',
                query)

            inference_response = pb_utils.InferenceResponse(output_tensors=[
                query_tensor
            ])
            responses.append(inference_response)

        # You should return a list of pb_utils.InferenceResponse. Length
        # of this list must match the length of `requests` list.
        return responses


    def finalize(self):
        print('Cleaning up...')
