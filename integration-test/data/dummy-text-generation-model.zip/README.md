---
Task: TextGeneration
Tags:
  - TextGeneration
  - GPT-2
  - Test
---

# Test repo
This is dummy Text Generation model used for testing purpose