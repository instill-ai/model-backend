---
Task: TextToImage
Tags:
  - TextToImage
  - Test
---

# Test repo
This is a dummy text to image model for testing purpose
