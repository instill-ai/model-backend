---
Task: TextToImage
Tags:
  - TextToImage
  - Diffusion
  - Text-To-Image
  - Test
---

# Test repo
This is dummy Text to Image model used for testing purpose