---
Task: VisualQuestionAnswering
Tags:
  - VisualQuestionAnswering
  - Test
---

# Test repo
This is a dummy visual question answering model for testing purpose
