---
Task: VisualQuestionAnswering
Tags:
  - VisualQuestionAnswering
  - GPT-2
  - Test
---

# Test repo

This is dummy Visual Question Answering model used for testing purpose
