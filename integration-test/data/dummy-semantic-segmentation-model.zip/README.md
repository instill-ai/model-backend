---
Task: SemanticSegmentation
Tags:
  - SemanticSegmentation
  - Test
---

# Test repo
This is dummy semantic segmentation model used for testing purpose