---
Task: SemanticSegmentation
Tags:
  - SemanticSegmentation
  - Test
---

# Test repo
This is a dummy semantic segmentation model for testing purpose
