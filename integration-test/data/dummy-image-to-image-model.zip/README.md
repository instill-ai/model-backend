---
Task: ImageToImage
Tags:
  - ImageToImage
  - Diffusion
  - Image-To-Image
  - Test
---

# Test repo

This is dummy Image to Image model used for testing purpose
