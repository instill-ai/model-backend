---
Task: ImageToImage
Tags:
  - ImageToImage
  - Test
---

# Test repo
This is a dummy text to image model for testing purpose
